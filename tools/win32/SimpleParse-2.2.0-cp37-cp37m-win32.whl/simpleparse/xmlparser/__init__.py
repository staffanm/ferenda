"""XML Parsing package

At the moment it's really limited,
but it does the basics, and the rest
is mostly just a matter of fiddling
about with Unicode and CharacterType
support.  There is only very minimal
support for Reference types, basically
we note that a Reference exists, but
don't do any further processing of it.
"""